#! /usr/bin/env python
# coding=utf-8
import SM9gentest2
import sys

reload(sys)
import shutil
# sys.setdefaultencoding("utf-8")
import csc.csclxmls
import path
import os , time

cfg = csc.csclxmls.node.cfgfile()

# if cfg('/root/item[@key="Pid check"]').text:
#     if not cfg.pidfilecheck():
#         print cfg('/root/item[@key="Exit Error"]').text
#         sys.exit(1)
# try:

# code starts here --------------------------------------------------------------------------------
# path-ing settings.xml
pth = path.path('settings.xml')
cc = csc.csclxmls.node(pth)
SM9gentest2.sm9_firefox_start()
# login
SM9gentest2.sm9_login()
# choose nav
SM9gentest2.sm9_navpanel(4)
SM9gentest2.sm9_opensearch(2)
a = SM9gentest2.sm9_buttons()
a.cancel()

#     print traceback.format_exc()
# finally:
#     if cfg('/root/item[@key="Pid check"]').text:
#         if cfg.pidfilecheck():
#             print cfg('/root/item[@key="Exit"]').text
#             cfg.pidfile.unlink()
#             sys.exit()
